package Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	Ball_Test.class,
	Player_Test.class,
	Text_Block_Test.class
})

public class TestSuite {

}
